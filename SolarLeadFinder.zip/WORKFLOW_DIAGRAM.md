# 🔄 Solar Lead Finder — Workflow Diagram

## Full Node Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    SOLAR LEAD FINDER                        │
│                   n8n Workflow v1.0                         │
└─────────────────────────────────────────────────────────────┘

 [▶ Manual Trigger]
        │
        ▼
 [✏️ Edit Fields]          ← Set: company list sheet ID, 
        │                       daily limit, target column names
        ▼
 [📊 Get Rows in Sheet]    ← Reads all 52 companies from Google Sheets
        │
        ├─── ERROR ──► [📧 Gmail: Send ERROR alert] ──► END
        │
        ▼
 [🚦 DAILY LIMIT]          ← Stops execution if quota reached today
        │
        ▼
 [❓ IF node]               ← Has this row already been processed?
        │                     Checks "Status" column in sheet
        │
  YES ──┤                   ← Skip (already done)
        │
  NO    ▼
 [🔁 Loop Over Items]       ← Iterates one company at a time
        │
        ▼
 [⏱️ Wait]                  ← Rate-limit delay between API calls
        │
        ▼
 [🔍 SerpAPI]               ← Google Search:
        │                     "[Company] CEO email"
        │                     "[CEO Name] [Company] contact"
        ▼
 [🤖 Message a Model]       ← OpenAI GPT-4:
        │                     Extract personal email from search results
        │                     Ignore generic emails (info@, contact@)
        │                     Return confidence score
        ▼
 [✏️ Edit Fields1]          ← Normalize GPT-4 output into clean fields
        │
        ▼
 [🔀 Switch]                ← Route based on result:
        │
        ├── Email FOUND ──► [📊 Append Row in Sheet]   ← New lead logged ✅
        │
        ├── Row EXISTS  ──► [📊 Update Row in Sheet]   ← Existing row updated 🔄
        │
        ├── ERROR ──────► [📧 Gmail: Send ERROR alert] ← Notified of failure 📬
        │                        │
        │                        ▼
        │                 [⛔ Stop and Error]
        │
        └── FALLBACK ───► [🔁 Replace Me]              ← Placeholder (to be wired)
```

---

## Node Descriptions

| Node | Type | Purpose |
|------|------|---------|
| Manual Trigger | Trigger | Starts the workflow on demand |
| Edit Fields | Set | Configures runtime variables |
| Get Rows in Sheet | Google Sheets | Reads the 52-company input list |
| Gmail (Error) | Gmail | Sends alert if sheet read fails |
| DAILY LIMIT | Code/IF | Enforces daily API call cap |
| IF | Conditional | Skips already-processed rows |
| Loop Over Items | Loop | Processes companies one by one |
| Wait | Wait | Adds delay between iterations |
| SerpAPI | HTTP Request | Searches Google for CEO emails |
| Message a Model | OpenAI | GPT-4 extracts & validates email |
| Edit Fields1 | Set | Normalizes output fields |
| Switch | Switch | Routes to correct output action |
| Append Row in Sheet | Google Sheets | Logs new leads |
| Update Row in Sheet | Google Sheets | Updates existing entries |
| Code in JavaScript | Code | Custom data transformation |
| Gmail (Error 5) | Gmail | Error notification for failures |
| Stop and Error | Error | Hard stops on critical failures |
| Replace Me | Placeholder | Unfinished branch — to be completed |

---

## Data Flow

```
INPUT (Google Sheets)
┌────────────────┬──────────────┬────────┬──────────┬───────┬────────────────┐
│ Company Name   │ Website      │ Status │ CEO Name │ Email │ Confidence     │
├────────────────┼──────────────┼────────┼──────────┼───────┼────────────────┤
│ SunPower CA    │ sunpower.ca  │ ─      │ ─        │ ─     │ ─              │
│ ...            │ ...          │ ─      │ ─        │ ─     │ ─              │
└────────────────┴──────────────┴────────┴──────────┴───────┴────────────────┘
                                    │
                              [Workflow runs]
                                    │
                                    ▼
OUTPUT (Google Sheets — auto-filled)
┌────────────────┬──────────────┬───────────┬──────────────┬──────────────────┬────────────────┐
│ Company Name   │ Website      │ Status    │ CEO Name     │ Email            │ Confidence     │
├────────────────┼──────────────┼───────────┼──────────────┼──────────────────┼────────────────┤
│ SunPower CA    │ sunpower.ca  │ ✅ Found  │ John Smith   │ john@sunpower.ca │ High           │
│ ...            │ ...          │ ❌ Failed │ ─            │ ─                │ ─              │
└────────────────┴──────────────┴───────────┴──────────────┴──────────────────┴────────────────┘
```

---

## Known Issues & TODOs

- [ ] **Replace Me node** — unfinished branch, needs to be wired or removed
- [ ] **Deduplication** — verify IF node correctly skips reprocessed rows
- [ ] **Fixed Wait delay** — consider replacing with exponential backoff on API errors
- [ ] **LinkedIn layer** — add as secondary source for higher confidence emails
